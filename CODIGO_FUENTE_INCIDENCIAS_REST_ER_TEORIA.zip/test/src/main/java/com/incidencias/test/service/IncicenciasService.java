/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.incidencias.test.service;

import com.incidencias.test.dto.IncidenciaDto;
import java.util.Date;
import java.util.List;

/**
 *
 * @author richi
 */
public interface IncicenciasService {

       List<IncidenciaDto>  getListasByDate(Date start  ,Date end ,String operador);
       
       
    
}
