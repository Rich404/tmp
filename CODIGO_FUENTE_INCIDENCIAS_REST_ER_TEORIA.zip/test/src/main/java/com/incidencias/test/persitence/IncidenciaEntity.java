/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.incidencias.test.persitence;

import java.util.Date;

/**
 *
 * @author richi
 */

@Entity
@Table("Incidencias")
public class IncidenciaEntity {
    
    @Column("ID")
    private int id;
    @Column("ID_EMPLEADO")
    private EmpleadoEntity idEmpleado;
    @Column("FECHA")
    private Date fecha;
    @Column("ESTATUS")
    private String estatus;
    @Column("SERVICIO")
    private String servicio;
    @Column("OPERADOR_ALTA")
    private  int idOperadorAlta;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public EmpleadoEntity getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(EmpleadoEntity idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getEstatus() {
        return estatus;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

    public int getIdOperadorAlta() {
        return idOperadorAlta;
    }

    public void setIdOperadorAlta(int idOperadorAlta) {
        this.idOperadorAlta = idOperadorAlta;
    }
    
    
    
    
}
