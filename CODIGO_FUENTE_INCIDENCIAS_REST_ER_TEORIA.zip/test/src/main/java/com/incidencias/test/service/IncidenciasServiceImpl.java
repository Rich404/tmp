/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.incidencias.test.service;

import com.incidencias.test.dto.IncidenciaDto;
import com.incidencias.test.persitence.IncidenciaEntity;
import com.incidencias.test.persitence.IncidenciaRepository;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author richi
 */
@Service
public class IncidenciasServiceImpl implements IncicenciasService{

    @Autowired
    private IncidenciaRepository  incienciasRepo;
    
    @Override
    public List<IncidenciaDto> getListasByDate(Date start  ,Date end ,String operador) {
       List<IncidenciaDto>  lista  =  new ArrayList<> ();
        List<IncidenciaEntity> optionalList = incienciasRepo.getCurrentIncidenciasOfDay(start, end, operador);
        
        for (IncidenciaEntity incidenciaEntity : optionalList) {
            
            IncidenciaDto dto =  new IncidenciaDto(incidenciaEntity.getId(), incidenciaEntity.getIdEmpleado().getEmpleado(),incidenciaEntity.getEstatus(), incidenciaEntity.getFecha());
            lista.add(dto);
        }
       
       return lista;
           
    }
    
}
