/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.incidencias.test.persitence;

import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author richi
 */
@Repository
public interface IncidenciaRepository extends CrudRepository<IncidenciaEntity,Integer>{
    
    // HQL
    @Query(" select * from IncidenciaEntity where  fecha bettween  1? and  ?2 and ?3 ")
    List<IncidenciaEntity> getCurrentIncidenciasOfDay(Date start, Date end ,String operador);
    
    
    @Query(" select count(id) from IncidenciaEntity where  estado = ?1 ")
    int getIncidenciasByState(String state);
    
    
    
    @Query(" select count(distinct(servicio)) from IncidenciaEntity  ")
    int getIncidenciasServiciosConsultado();
    
    
    
    
    
    
}
