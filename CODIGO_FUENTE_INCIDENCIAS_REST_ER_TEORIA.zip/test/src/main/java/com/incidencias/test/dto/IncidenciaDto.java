/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.incidencias.test.dto;

import java.util.Date;

/**
 *
 * @author richi
 */
public class IncidenciaDto {
    
    private int idIncidencia;
    
    private String empleadoNombre;
    
    private String estado;
    
    private Date Fecha;

    public IncidenciaDto(int idIncidencia, String empleadoNombre, String estado, Date Fecha) {
        this.idIncidencia = idIncidencia;
        this.empleadoNombre = empleadoNombre;
        this.estado = estado;
        this.Fecha = Fecha;
    }

    
    
    public int getIdIncidencia() {
        return idIncidencia;
    }

    public void setIdIncidencia(int idIncidencia) {
        this.idIncidencia = idIncidencia;
    }

    public String getEmpleadoNombre() {
        return empleadoNombre;
    }

    public void setEmpleadoNombre(String empleadoNombre) {
        this.empleadoNombre = empleadoNombre;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date Fecha) {
        this.Fecha = Fecha;
    }
    
    
    
}
