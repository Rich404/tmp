/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.incidencias.test.controller;

import com.incidencias.test.dto.IncidenciaDto;
import com.incidencias.test.dto.IncidenciaRequestDateDto;
import com.incidencias.test.service.IncicenciasService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author richi
 */
@Controller
@RequestMapping("api/incidencias")
public class IncidenciasController {
    
    @Autowired
    private IncicenciasService incidencias;
   
    
    @PostMapping(path = "/incidenciasHoy")
    @ResponseBody
    public List<IncidenciaDto> getIncicenciasByDate(@Valid @RequestBody IncidenciaRequestDateDto requestDateDto)
    {
        return incidencias.getListasByDate(requestDateDto.getStart(), requestDateDto.getEnd(), requestDateDto.getOperador());
    }
    
}
