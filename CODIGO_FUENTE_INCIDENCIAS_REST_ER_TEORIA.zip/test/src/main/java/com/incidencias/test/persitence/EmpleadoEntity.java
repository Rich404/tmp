/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.incidencias.test.persitence;

import org.springframework.boot.autoconfigure.domain.EntityScan;

/**
 *
 * @author richi
 */
@Entity
@Table("Empleado")
public class EmpleadoEntity {
    
    @Column("ID")
    private int id;
    @Column("Nombre")
    private String empleado;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmpleado() {
        return empleado;
    }

    public void setEmpleado(String empleado) {
        this.empleado = empleado;
    }
    
    
    
            
}
